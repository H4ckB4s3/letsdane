
const $ = id => document.getElementById(id);

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    }
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Request failed');
  }

  return data;
}

async function loadSettings() {
  try {
    const settings = await api('/api/settings');

    $('primary').value = settings.primary;
    $('secondary').value = settings.secondary;
    $('use-secondary').checked = settings.useSecondary;
    $('secondary').disabled = !settings.useSecondary;
    $('test-secondary').disabled = !settings.useSecondary;
  } catch (error) {
    $('save-result').textContent = error.message;
  }
}

async function testResolver(server, output) {
  $(output).textContent = 'Testing...';

  try {
    const result = await api('/api/resolvers/test', {
      method: 'POST',
      body: JSON.stringify({ server })
    });

    $(output).textContent = result.ok
      ? `✓ Responding (${result.answers.length} answers)`
      : `Failed: ${result.responseCode}`;

    $(output).className = result.ok
      ? 'result success'
      : 'result failure';
  } catch (error) {
    $(output).textContent = `✗ ${error.message}`;
    $(output).className = 'result failure';
  }
}

$('test-primary').addEventListener('click', () => {
  testResolver($('primary').value.trim(), 'primary-result');
});

$('test-secondary').addEventListener('click', () => {
  testResolver($('secondary').value.trim(), 'secondary-result');
});

$('use-secondary').addEventListener('change', () => {
  const enabled = $('use-secondary').checked;
  $('secondary').disabled = !enabled;
  $('test-secondary').disabled = !enabled;
});

$('save-settings').addEventListener('click', async () => {
  $('save-result').textContent = 'Saving...';

  try {
    const result = await api('/api/settings', {
      method: 'PUT',
      body: JSON.stringify({
        primary: $('primary').value.trim(),
        secondary: $('secondary').value.trim(),
        useSecondary: $('use-secondary').checked
      })
    });

    $('save-result').textContent = '✓ Settings saved successfully';
    $('active-resolver').textContent = result.settings.primary;
  } catch (error) {
    $('save-result').textContent = `✗ ${error.message}`;
  }
});

async function loadStatus() {
  try {
    const data = await api('/api/status');

    $('proxy-status').textContent = data.proxy.status;
    $('proxy-address').textContent = data.proxy.address;
    $('ca-status').textContent = data.ca.ready ? 'Ready' : 'Not ready';
    $('active-resolver').textContent =
      data.resolver.active || 'Awaiting DNS query';

    if (data.ca.ready) {
      const info = data.ca;
      const dl = $('ca-info');
      dl.replaceChildren();

      const fields = [
        ['Subject', info.subject],
        ['Issuer', info.issuer],
        ['Valid until', new Date(info.notAfter).toLocaleDateString()],
        ['Fingerprint', info.fingerprint]
      ];

      for (const [name, value] of fields) {
        const dt = document.createElement('dt');
        const dd = document.createElement('dd');
        dt.textContent = name;
        dd.textContent = value || '';
        dl.append(dt, dd);
      }
    }
  } catch (error) {
    $('overall-status').textContent = 'Dashboard error';
    console.error(error);
  }
}

loadSettings();
loadStatus();
setInterval(loadStatus, 10000);
