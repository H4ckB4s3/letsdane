

import dns from 'node:dns';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { LocalCA } from './certificates/ca.js';
import { createDashboard } from './dashboard/server.js';
import { DaneProxy } from './proxy/http-proxy.js';
import { DnsResolver } from './dns/resolver.js';
import { SettingsStore } from './config/settings.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  console.log("Let's DANE JS — Security manager");

  const settingsStore = new SettingsStore(
    path.join(__dirname, '../data/settings.json')
  );

  const settings = settingsStore.get();

  const resolver = new DnsResolver(settings);

  dns.setServers([
    settings.primary,
    ...(settings.useSecondary ? [settings.secondary] : [])
  ]);

  console.log('\nDNS configuration');
  console.log('Primary:', settings.primary);
  console.log('Secondary:', settings.useSecondary
    ? settings.secondary
    : 'Disabled');

  const ca = new LocalCA(
    path.join(__dirname, '../data/ca')
  );

  const result = await ca.ensure();

  console.log(result.created
    ? 'Generated local CA'
    : 'Loaded existing local CA');

  const proxy = new DaneProxy(ca, {
    port: 8080,
    dns: settings,
    resolver
  });

  await proxy.start();

  const dashboard = createDashboard(ca, {
    port: 3000,
    proxyStatus: 'active',
    proxyAddress: '127.0.0.1:8080',
    settingsStore,
    resolver
  });

  console.log('\n================================');
  console.log('LetsDANE started');
  console.log('Dashboard: http://127.0.0.1:3000');
  console.log('Proxy:     http://127.0.0.1:8080');
  console.log('================================');
}

main().catch(error => {
  console.error('Startup failed:', error);
  process.exit(1);
});
