
import { Proxy } from 'http-mitm-proxy';
import { DnsResolver } from '../dns/resolver.js';
import { DnssecValidator } from '../dns/dnssec.js';
import path from 'node:path';

export class DaneProxy {
  constructor(ca, options = {}) {
    this.ca = ca;
    this.port = options.port || 8080;

    this.resolver = options.resolver ||
      new DnsResolver(options.dns);

    this.dnssec = new DnssecValidator(this.resolver);
    this.proxy = new Proxy();
  }

  async start() {
    this.proxy.onCertificateRequired = (hostname, callback) => {
      callback(null, {
        keyFile: null,
        certFile: null
      });
    };

    // SECURITY: Do not issue a trusted interception certificate
    // until the actual upstream TLS certificate has been obtained
    // and its SPKI has matched an authenticated TLSA record.
    this.proxy.onCertificateMissing = (ctx, files, callback) => {
      const hostname = ctx.hostname;

      console.error(
        `[DANE] BLOCKED ${hostname}: upstream DANE verification is not yet integrated`
      );

      callback(new Error(
        'DANE verification unavailable: refusing unauthenticated interception'
      ));
    };

    this.proxy.onError((ctx, error) => {
      console.error('[Proxy]', error?.message || error);
    });

    this.proxy.listen({
      port: this.port,
      host: '127.0.0.1',
      sslCaDir: path.join(process.cwd(), 'data', 'ca')
    });

    console.log(`DANE proxy listening on 127.0.0.1:${this.port}`);
    console.log('[DANE] Secure interception disabled until upstream verification is integrated.');
  }
}
