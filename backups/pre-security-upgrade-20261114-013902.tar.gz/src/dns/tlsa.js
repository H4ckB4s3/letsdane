
import crypto from 'node:crypto';
import { X509Certificate } from 'node:crypto';

function associationBuffer(value) {
  if (Buffer.isBuffer(value)) return value;

  if (value instanceof Uint8Array) {
    return Buffer.from(value);
  }

  if (typeof value === 'string') {
    const hex = value.replace(/\s+/g, '');

    if (/^(?:[0-9a-fA-F]{2})+$/.test(hex)) {
      return Buffer.from(hex, 'hex');
    }

    return Buffer.from(value, 'base64');
  }

  throw new Error('Invalid TLSA association data');
}

function getAssociation(record) {
  const data = record.data || record.dataFields || record;

  return {
    usage: Number(data.usage),
    selector: Number(data.selector),
    matchingType: Number(data.matchingType),
    association:
      data.certificateAssociationData ??
      data.certificate ??
      data.association ??
      data.data
  };
}

export class TlsaValidator {
  static validateDaneEE(certInput, records) {
    if (!records?.length) return false;

    try {
      const certificate = certInput instanceof X509Certificate
        ? certInput
        : new X509Certificate(certInput);

      const certificateDer = certificate.raw;

      const spkiDer = certificate.publicKey.export({
        type: 'spki',
        format: 'der'
      });

      for (const record of records) {
        const {
          usage,
          selector,
          matchingType,
          association
        } = getAssociation(record);

        if (usage !== 3 || !association) continue;

        let selected;

        if (selector === 0) {
          selected = certificateDer;
        } else if (selector === 1) {
          selected = spkiDer;
        } else {
          continue;
        }

        let calculated;

        if (matchingType === 0) {
          calculated = Buffer.from(selected);
        } else if (matchingType === 1) {
          calculated = crypto.createHash('sha256')
            .update(selected).digest();
        } else if (matchingType === 2) {
          calculated = crypto.createHash('sha512')
            .update(selected).digest();
        } else {
          continue;
        }

        const expected = associationBuffer(association);

        if (
          calculated.length === expected.length &&
          crypto.timingSafeEqual(calculated, expected)
        ) {
          return true;
        }
      }

      return false;
    } catch {
      return false;
    }
  }

  static isValid(cert, records) {
    return this.validateDaneEE(cert, records);
  }
}
