
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DnsResolver } from '../dns/resolver.js';
import { isIP } from 'node:net';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function createDashboard(ca, options = {}) {
  const app = express();
  const port = options.port || 3000;
  const publicDir = path.join(__dirname, '../../public');

  app.use(express.json({ limit: '20kb' }));
  app.use(express.static(publicDir));

  const settingsStore = options.settingsStore;
  const resolver = options.resolver;

  app.get('/api/status', (req, res) => {
    const info = ca.getInfo();

    res.json({
      proxy: {
        status: options.proxyStatus || 'stopped',
        address: options.proxyAddress || '127.0.0.1:8080'
      },
      dnssec: { enabled: true, status: 'configured' },
      tlsa: { enabled: true },
      ca: { ready: !!info, ...info },
      resolver: {
        active: resolver?.activeServer || null
      }
    });
  });

  app.get('/api/settings', (req, res) => {
    res.json(settingsStore.get());
  });

  app.put('/api/settings', (req, res) => {
    try {
      const saved = settingsStore.save(req.body);

      resolver.primary = saved.primary;
      resolver.secondary = saved.secondary;
      resolver.useSecondary = saved.useSecondary;
      resolver.timeout = saved.timeout;

      res.json({
        ok: true,
        settings: saved
      });
    } catch (error) {
      res.status(400).json({ ok: false, error: error.message });
    }
  });

  app.post('/api/resolvers/test', async (req, res) => {
    const server = String(req.body.server || '').trim();

    if (isIP(server) !== 4) {
      return res.status(400).json({
        ok: false,
        error: 'Invalid IPv4 address'
      });
    }

    try {
      const testResolver = new DnsResolver({
        primary: server,
        useSecondary: false,
        timeout: 4000
      });

      const response = await testResolver.query('syndicate', 'DS');

      res.json({
        ok: response.rcode === 'NOERROR',
        server,
        responseCode: response.rcode,
        answers: (response.answers || []).map(record => ({
          name: record.name,
          type: record.type,
          data: record.data
        }))
      });
    } catch (error) {
      res.status(502).json({
        ok: false,
        server,
        error: error.message
      });
    }
  });

  app.get('/api/ca/cert.pem', (req, res) => {
    try {
      res.setHeader('Content-Type', 'application/x-pem-file');
      res.setHeader('Content-Disposition',
        'attachment; filename="letsdane-ca.crt"');
      res.send(ca.getPublicCertPem());
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/ca/cert.der', (req, res) => {
    try {
      res.setHeader('Content-Type', 'application/pkix-cert');
      res.setHeader('Content-Disposition',
        'attachment; filename="letsdane-ca.der"');
      res.send(Buffer.from(ca.getPublicCertDer(), 'binary'));
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/ca/info', (req, res) => {
    res.json(ca.getInfo());
  });

  app.get('/api/health', (req, res) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
  });

  const server = app.listen(port, '127.0.0.1', () => {
    console.log(`Dashboard running at http://127.0.0.1:${port}`);
  });

  server.on('error', error => {
    console.error('[Dashboard]', error.message);
  });

  return { app, server, port };
}
